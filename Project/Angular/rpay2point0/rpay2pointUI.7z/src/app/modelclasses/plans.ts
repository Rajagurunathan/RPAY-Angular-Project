
export class plans
{
    plan_id:number;
    plan_name:string;
    plan_description:string;
    amount:number;
    validity:number;
    plan_type:string;
    operator_id:number;
}