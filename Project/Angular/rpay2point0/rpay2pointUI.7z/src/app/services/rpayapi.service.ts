import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule,HttpParams } from "@angular/common/http";
import { Observable } from 'rxjs';
@Injectable()
export class RpayapiService {
  constructor(private httpclient:HttpClient) { }

  //--------------------- AIRTEL

  getairtelplans():Observable<any>{
    return this.httpclient.get('https://rpay.mrwhitehost.in/api/values/getplansairtel');
  }

  getairtelPopularPlans():Observable<any>{
    return this.httpclient.get('https://rpay.mrwhitehost.in/api/values/airtelpp');
  }

  getairtelTalkTime():Observable<any>{
    return this.httpclient.get('https://rpay.mrwhitehost.in/api/values/airteltopup');
  }

  getairtelData():Observable<any>{
    return this.httpclient.get('https://rpay.mrwhitehost.in/api/values/airtel4gdata');
  }

  getairtelRoaming():Observable<any>{
    return this.httpclient.get('https://rpay.mrwhitehost.in/api/values/airtelgbroam');
  }

 //--------------------- BSNL

  getbsnlplans():Observable<any>{
    return this.httpclient.get('https://rpay.mrwhitehost.in/api/values/getplansbsnl');
  }

  getbsnlPopularPlans():Observable<any>{
    return this.httpclient.get('https://rpay.mrwhitehost.in/api/values/bsnlpp');
  }

  getbsnlTalkTime():Observable<any>{
    return this.httpclient.get('https://rpay.mrwhitehost.in/api/values/bsnltopup');
  }

  getbsnlData():Observable<any>{
    return this.httpclient.get('https://rpay.mrwhitehost.in/api/values/bsnl4gdata');
  }

  getbsnlRoaming():Observable<any>{
    return this.httpclient.get('https://rpay.mrwhitehost.in/api/values/bsnlgbroam');
  }

  //--------------------- JIO

  getjioplans():Observable<any>{
    return this.httpclient.get('https://rpay.mrwhitehost.in/api/values/getplansjio');
  }

  getjioPopularPlans():Observable<any>{
    return this.httpclient.get('https://rpay.mrwhitehost.in/api/values/jiopp');
  }

  getjioTalkTime():Observable<any>{
    return this.httpclient.get('https://rpay.mrwhitehost.in/api/values/jiotopup');
  }

  getjioData():Observable<any>{
    return this.httpclient.get('https://rpay.mrwhitehost.in/api/values/jio4gdata');
  }

  getjioRoaming():Observable<any>{
    return this.httpclient.get('https://rpay.mrwhitehost.in/api/values/bsnlgbroam');
  }

  //--------------------- VI

  getviplans():Observable<any>{
    return this.httpclient.get('https://rpay.mrwhitehost.in/api/values/getplansvi');
  }

  getviPopularPlans():Observable<any>{
    return this.httpclient.get('https://rpay.mrwhitehost.in/api/values/vipp');
  }

  getviTalkTime():Observable<any>{
    return this.httpclient.get('https://rpay.mrwhitehost.in/api/values/vitopup');
  }

  getviData():Observable<any>{
    return this.httpclient.get('https://rpay.mrwhitehost.in/api/values/vi4gdata');
  }

  getviRoaming():Observable<any>{
    return this.httpclient.get('https://rpay.mrwhitehost.in/api/values/vigbroam');
  }

  
}
