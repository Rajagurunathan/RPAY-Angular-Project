
export class Plan
{
    plan_id: number;
    plan_name:string;
    plan_description:string;
    amount:number;
    validity:number;
    paln_type:number;
    operator_id:number;
}